﻿INSERT INTO external_users (login, password)
VALUES ('$login', '$hashed_password')