select
    prod_id,
    prod_name as name,
    prod_price as price
from products
order by prod_name;