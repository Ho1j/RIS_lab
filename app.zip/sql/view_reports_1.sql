SELECT DISTINCT MONTH(order_date) as month, YEAR(order_date) as year
FROM report_1