SELECT DISTINCT prod_cat
FROM products