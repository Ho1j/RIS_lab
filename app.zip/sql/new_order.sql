INSERT INTO user_orders(user_id, order_date, order_sum)
VALUES('$user_id', CURRENT_DATE(), '$sum');
